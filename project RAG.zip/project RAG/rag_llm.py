# rag_llm.py

import faiss
import pickle
import numpy as np
from sentence_transformers import SentenceTransformer
import ollama

# -----------------------------
# Load FAISS index & chunks
# -----------------------------
index = faiss.read_index("vector.index")

with open("chunks.pkl", "rb") as f:
    chunks = pickle.load(f)

# -----------------------------
# Load embedding model
# -----------------------------
embedder = SentenceTransformer("all-MiniLM-L6-v2")

print("RAG + LLM system ready (type 'exit' to quit)")

# -----------------------------
# Query loop
# -----------------------------
while True:
    query = input("\nYour question: ")

    if query.lower() == "exit":
        break

    # Embed query
    query_vector = embedder.encode(query)

    # Retrieve top chunks
    D, I = index.search(
        np.array([query_vector]).astype("float32"), 3
    )

    context = "\n\n".join(
        [chunks[i].page_content for i in I[0]]
    )

    # Prompt for LLM
    prompt = f"""
You are an AI assistant.
Answer the question using ONLY the context below.

Context:
{context}

Question:
{query}

Answer:
"""

    # Generate answer
    response = ollama.chat(
        model = "phi3:mini",
        messages=[{"role": "user", "content": prompt}]
    )

    print("\nAnswer:\n")
    print(response["message"]["content"])
    print("\n" + "-" * 70)
