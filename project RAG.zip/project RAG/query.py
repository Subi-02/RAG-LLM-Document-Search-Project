# query.py

import faiss
import pickle
import numpy as np
from sentence_transformers import SentenceTransformer

# -----------------------------
# Load saved index & chunks
# -----------------------------
index = faiss.read_index("vector.index")

with open("chunks.pkl", "rb") as f:
    chunks = pickle.load(f)

# -----------------------------
# Load embedding model
# -----------------------------
model = SentenceTransformer("all-MiniLM-L6-v2")

print("RAG system ready. Ask your question (type 'exit' to quit)")

# -----------------------------
# Interactive query loop
# -----------------------------
while True:
    query = input("\nYour question: ")

    if query.lower() == "exit":
        break

    query_vector = model.encode(query)

    D, I = index.search(
        np.array([query_vector]).astype("float32"), 3
    )

    print("\nTop relevant results:\n")

    for i, idx in enumerate(I[0], 1):
        print(f"Result {i}:\n{chunks[idx].page_content}\n{'-'*60}")
