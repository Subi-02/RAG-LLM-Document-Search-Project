# ingest.py

import os
import numpy as np
import faiss
import pickle
# ✅ Correct imports for LangChain 1.x
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
# -----------------------------
# Documents folder
# -----------------------------
DOCS_FOLDER = "docs"

# -----------------------------
# Load documents
# -----------------------------
documents = []

for file_name in os.listdir(DOCS_FOLDER):
    file_path = os.path.join(DOCS_FOLDER, file_name)

    if file_name.lower().endswith(".pdf"):
        loader = PyPDFLoader(file_path)
        documents.extend(loader.load())

    elif file_name.lower().endswith(".docx"):
        loader = Docx2txtLoader(file_path)
        documents.extend(loader.load())

print(f"Loaded {len(documents)} pages")

# -----------------------------
# Split text into chunks
# -----------------------------
splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=100
)

chunks = splitter.split_documents(documents)
print(f"Split into {len(chunks)} chunks")

# -----------------------------
# Create embeddings
# -----------------------------
model = SentenceTransformer("all-MiniLM-L6-v2")

vectors = model.encode(
    [chunk.page_content for chunk in chunks],
    show_progress_bar=True
)



# -----------------------------
# Store in FAISS
# -----------------------------
dimension = len(vectors[0])
index = faiss.IndexFlatL2(dimension)
index.add(np.array(vectors).astype("float32"))

print("FAISS index created successfully!")

# -----------------------------
# Test semantic search
# -----------------------------
def search(query, k=3):
    query_vector = model.encode(query)
    D, I = index.search(
        np.array([query_vector]).astype("float32"), k
    )
    return [chunks[i].page_content for i in I[0]]

# Example query
results = search("Who is Alice?")
for i, r in enumerate(results, 1):
    print(f"\nResult {i}:\n{r}\n{'-'*60}")
    
faiss.write_index(index, "vector.index")

with open("chunks.pkl", "wb") as f:
    pickle.dump(chunks, f)

print("Index and chunks saved successfully!")
